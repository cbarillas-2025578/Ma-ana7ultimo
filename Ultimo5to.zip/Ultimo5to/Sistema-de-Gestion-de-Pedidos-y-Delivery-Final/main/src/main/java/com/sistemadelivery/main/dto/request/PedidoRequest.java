package com.sistemadelivery.main.dto.request;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.sistemadelivery.main.validation.SinProductosDuplicados;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Positive;

import java.util.List;

/**
 * Creación de pedido multiproducto de UN SOLO comercio.
 * Acepta opcionalmente {@code comercioId}; si se omite, se deduce del comercio
 * de los productos. El campo se serializa como {@code productos}, pero también
 * se acepta la variante {@code items} por compatibilidad.
 * No acepta precios, subtotales, costo de envío, monto total,
 * identificador de cliente ni de repartidor: todo se calcula/obtiene en el servidor.
 */
@SinProductosDuplicados
public record PedidoRequest(
        @Positive(message = "El id del comercio debe ser positivo")
        Long comercioId,

        @NotEmpty(message = "El pedido debe incluir al menos un producto")
        @Valid
        @JsonAlias("items")
        List<ItemPedidoRequest> productos) {
}
